SUPPLEMENTARY ANALYSIS OUTPUTS
Finance-fraud hyperparameter-optimisation benchmark

This folder contains the analysis outputs generated from the supplied recorded workbook:
  Input: Complete data(4).xlsx
  Script: finance_hpo_conference_script(1).py

The script was run in analysis mode. It did not fit any models, rerun the benchmark,
or modify the recorded workbook. The 300 existing rows were analysed as recorded.
Runtime ANOVA was not included, in line with the revised paper.

FILES
-----
analysis_metadata.json
  Summary of the input row count, algorithms, tuners, split IDs, CV-fold description,
  nominal candidate-event budget, and whether runtime ANOVA was included.

summary_by_algorithm.csv
  Algorithm-level F1-macro mean, standard deviation, and maximum across-tuner spread.

summary_by_algorithm_tuner.csv
  All 30 algorithm-tuner combinations: sample size, F1-macro mean/SD, and runtime
  mean/SD/median/minimum/maximum. This is the primary compact descriptive-results table.

ranked_balance_all_30.csv
  All 30 configurations sorted by the study-specific Ranked Balance score, including
  the component normalisations used to calculate the score.

pareto_frontier.csv
  The non-dominated configurations for mean F1-macro and mean runtime.

runtime_kendall_concordance.csv
  Kendall's W, approximate chi-square statistic, degrees of freedom, and approximate
  p-value for consistency of runtime rankings across classifier families and tuners.

friedman_tests.csv
  Split-paired Friedman statistics by classifier family, raw p-values, Bonferroni-adjusted
  p-values across six families, Nemenyi critical difference, and interpretive notes.

friedman_average_ranks.csv
  Average tuner ranks within each classifier family; lower rank means better F1-macro.

nemenyi_posthoc.csv
  All pairwise average-rank differences and their comparisons with the Nemenyi critical
  difference. Interpret as exploratory because the repeated outer splits overlap.

corrected_paired_tost.csv
  The 15 non-identical, non-zero-variance pairwise corrected-resampling equivalence tests
  versus Halving Search, including raw and Holm-adjusted TOST p-values and pointwise
  corrected 90% confidence intervals.

equivalence_exact_ties.csv
  Exact observed score-sequence ties versus Halving Search. These have no inferential
  p-value assigned.

equivalence_zero_variance_exceptions.csv
  Non-identical paired differences with zero variance for which corrected SE would not
  be estimable. This file currently has headers and no data rows; no such exception was
  found in this analysis run.

equivalence_summary.csv
  Per-family counts of non-identical equivalence tests, tests supporting equivalence after
  Holm adjustment, and exact observed ties.

resource_budget.csv
  Illustrative candidate-input row-exposure calculations for the recorded nominal
  schedules. These are not CPU-work or elapsed-time equivalence claims and exclude the
  final refit as documented by the script.

IMPORTANT INTERPRETATION NOTES
------------------------------
1. The workbook includes 300 measurements: 6 algorithms x 5 tuners x 10 split IDs.
2. The ten outer splits reuse the same transaction pool. Split-paired tests are therefore
   exploratory; the results do not make the split observations independent.
3. Equivalence means equivalence under the chosen +/-0.0005 F1-macro margin and the
   stated corrected-resampling/Holm procedure, not exact equality in every case.
4. Exact observed ties are kept separate from inferential TOST results.
5. Equal nominal candidate-scoring event counts do not imply equal computational work.
6. The recorded F1-macro and runtime values have not been altered.

REPRODUCING THESE OUTPUTS
------------------------
With Python and the script dependencies installed, place the workbook and script together
(or supply their full paths) and run:

python finance_hpo_conference_script.py --mode analyze --input "Complete data(4).xlsx" --outdir analysis_outputs

The script's current default input filename is "Complete data(2).xlsx", so specify the
actual filename with --input when using the supplied "Complete data(4).xlsx" workbook.
